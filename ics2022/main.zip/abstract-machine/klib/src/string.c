#include <klib.h>
#include <klib-macros.h>
#include <stdint.h>

#if !defined(__ISA_NATIVE__) || defined(__NATIVE_USE_KLIB__)

size_t strlen(const char *s) {
  size_t ret = 0;
	size_t temp = 0;
	size_t i =0;
	while(s[i]!='\0'){
		ret++;
		if(ret<temp){
			printf("overflow\n");
			assert(0);
		}
		temp = ret;
	}
	return ret;
	//panic("Not implemented");
}

char *strcpy(char *dst, const char *src) {
  char * ret = dst;
	int i = 0;
	while(src[i]!='\0'){
		dst[i]=src[i];
		i++;
	}
	return ret;
	//panic("Not implemented");
}

char *strncpy(char *dst, const char *src, size_t n) {
  size_t i = 0;
	char * ret =dst;
	while((i<n)&&(src[i]!='\0')){
		dst[i]=src[i];
		i++;
	}
	//meet src[i]=='\0'
	while(i<n){
	    dst[i]='\0';
	    i++;
	}
	return ret;
	//panic("Not implemented");
}

char *strcat(char *dst, const char *src) {
  char * ret = dst;
	size_t i = 0;
	size_t j = 0;
	while(dst[i]!='\0'){
		i++;
	}
	while(src[j]!='\0'){
		dst[i]=src[j];
		i++;
		j++;
	}
	dst[i]='\0';
	return ret;
	//panic("Not implemented");
}
int is_anyone_null(const char * s1,const char * s2){
    int i =0;
    if(s1[i]=='\0'){
        if(s2[i]=='\0'){
	    return 0;
        }
	else{
	    return -1;
	}
    }
    if(s2[i]=='\0'){
        return 1;
    }
    return 2; //no one is null
}
int strcmp(const char *s1, const char *s2) {
  size_t i =0;
  int temp = is_anyone_null(s1,s2);
  if(temp!=2){
      return temp;
  }
	while(s1[i]==s2[i]){
		i++;
		temp = is_anyone_null(s1+i,s2+i);
		if(temp!=2){
		    return temp;
		}
	}
	if(s1[i]<s2[i]){
		return -1;
	}
	else if(s1[i]==s2[i]){
		return 0;
	}
	else{
		return 1;
	}
	//panic("Not implemented");
}

int strncmp(const char *s1, const char *s2, size_t n) {
  size_t i = 0;
  int temp = is_anyone_null(s1,s2);
  if(temp!=2){
      return temp;
  }
	while((s1[i]==s2[i])&&(i<n)){
		i++;
		temp = is_anyone_null(s1+i,s2+i);
		if(temp!=2){
		    return temp;
		}
	}
	if(i==n){
		return 0;
	}

	if(s1[i]<s2[i]){
		return -1;
	}
	else if(s1[i]==s2[i]){
		return 0;
	}
	else{
		return 1;
	}
	//panic("Not implemented");
}

void *memset(void *s, int c, size_t n) {
  void * ret = s;
	char * temp = (char *)s;
	size_t i =0;
	while(i<n){
		temp[i]=c;
		i++;
	}
	return ret;
	//panic("Not implemented");
}

void *memmove(void *dst, const void *src, size_t n) {
  panic("Not implemented");
}

void *memcpy(void *out, const void *in, size_t n) {
  size_t i=0;
	void * ret = out;
	char * s1=(char *)out;
	char * s2=(char *)in;
	while(i<n){
		s1[i]=s2[i];
		i++;
	}
	return ret;
	//panic("Not implemented");
}

int memcmp(const void *s1, const void *s2, size_t n) {
  //int ret = 0;
  char * t1 = (char *)s1;
  char * t2 = (char *)s2;
  size_t i = 0;
  int temp = is_anyone_null(t1,t2);
  if(temp!=2){
      return temp;
  }
  while((t1[i]==t2[i])&&(i<n)){
    i++;
    if(i==n){
        return 0;
    }
    temp = is_anyone_null(s1+i,s2+i);
    if(temp!=2){
	return temp;
    }
    }
  if(i==n){
    return 0;
    }
  if(t1[i]<t2[i]){
		return -1;
	}
	else if(t1[i]==t2[i]){
		return 0;
	}
	else{
		return 1;
	}
  //panic("Not implemented");
}

#endif
