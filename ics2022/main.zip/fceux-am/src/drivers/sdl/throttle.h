void RefreshThrottleFPS();
int SpeedThrottle(void);
